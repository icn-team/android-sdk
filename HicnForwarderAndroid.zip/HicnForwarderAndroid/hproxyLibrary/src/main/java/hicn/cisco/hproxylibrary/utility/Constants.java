package hicn.cisco.hproxylibrary.utility;

public class Constants {
    public static final int FOREGROUND_SERVICE = 101;
}
