package hicn.cisco.hproxylibrary.service;

import java.io.Serializable;

import hicn.cisco.hproxylibrary.supportlibrary.SocketBinder;

public abstract class AbstractForwarder implements Serializable {
    public abstract boolean isRunningForwarder();
}
