/*
 * Copyright (c) 2019-2020 Cisco and/or its affiliates.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at:
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package hicn.cisco.hproxylibrary.service;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.VpnService;
import android.os.Handler;
import android.os.Message;
import android.os.ParcelFileDescriptor;
import android.preference.PreferenceManager;
import android.util.Log;
import android.widget.Toast;

import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

import hicn.cisco.hproxylibrary.R;
import hicn.cisco.hproxylibrary.supportlibrary.HProxyLibrary;
import hicn.cisco.hproxylibrary.supportlibrary.PuntingSpec;
import hicn.cisco.hproxylibrary.utility.Constants;

//import com.samsung.android.hicn.HicnManager; // A11v1

/*
 * Ideally we would love the following class hierarchy:
 *                      BackendProxyService     VpnService
 *                         /              \         /
 *       BackendProxyNativeService    BackendProxyVpnService
 *
 * As Java does not support multiple inheritance, we use the ProxyBackend class
 * as a composition element instanciated from either VpnService or
 * BackendProxyService, depending on the availability of punting APIs.
 *
 * This class takes a reference to the parent service and takes care of the
 * foreground notification on behalf of the service.
 */
public class ProxyBackend implements Runnable, Handler.Callback {
    /**
     * Maximum packet size is constrained by the MTU, which is given as a signed short.
     */
    private static final int MAX_PACKET_SIZE = 1400;

    /**
     * Time to wait in between losing the connection and retrying.
     */
    private static final long RECONNECT_WAIT_MS = TimeUnit.SECONDS.toMillis(3);

    /**
     * Number of periods of length {@IDLE_INTERVAL_MS} to wait before declaring the handshake a
     * complete and abject failure.
     */
    private static final int MAX_HANDSHAKE_ATTEMPTS = 10; // 50

    protected static Object sHicnManager = null;
    protected static Class<?> sIHicnManagerClass = null;
    protected static boolean sHicnServiceGot = false;

    private final AtomicReference<Thread> mConnectingThread = new AtomicReference<>();

    private String mServerName = "";
    private int mServerPort = -1;
    private String mSharedSecret = "";
    private PendingIntent mConfigureIntent;
    private ParcelFileDescriptor mInterface;

    protected Service mParentService;
    protected int mTunFd = -1;
    //protected ParcelFileDescriptor mTunPFd; // A11v1, moved to native class
    protected Handler mHandler;
    protected Properties mParameters;
    //protected String[] mProxiedPackages;

/*
    private static HicnManager hicnMgr = null; // A11v1

    public static ProxyBackend getProxyBackend(final Service parentService) {
        // if (getHicnService()) { // A10
        hicnMgr = HicnManager.getInstance(parentService); // A11v1
        if (hicnMgr != null) {
            Log.i("HProxyBackend", "Using Native backend");
            return new ProxyBackendNative(parentService);
        } else {
            Log.i("HProxyBackend", "Using VPN backend");
            return new ProxyBackend(parentService);
        }
    }
*/

/*
    // A10
    public static boolean getHicnService() {
        if (HProxy.isHProxyEnabled()) {
            try {
                if (!sHicnServiceGot) {
                    Class<?> serviceManagerClass = Class.forName("android.os.ServiceManager");
                    Method getServiceMethod = serviceManagerClass.getMethod("getService", new Class[]{String.class});
                    Object serviceManager = getServiceMethod.invoke(null, new Object[]{"hicn_service"});
                    Class<?> stubClass = Class.forName(HProxy.getHicnServiceName());
                    Method[] methodNames = stubClass.getMethods();
                    int counter = 0;
                    for (; counter < methodNames.length; counter++) {
                        if (methodNames[counter].getName().equals("asInterface"))
                            break;
                    }
                    sHicnManager = methodNames[counter].invoke(null, serviceManager);
                    if (sHicnManager != null) {
                        sIHicnManagerClass = sHicnManager.getClass();
                    }
                    sHicnServiceGot = true;
                }

                return sHicnServiceGot;

            } catch (Throwable e) {
            }
        }

        return sHicnServiceGot;
    }

    // A11v1
    public static boolean getHicnService() {
        if (HProxy.isHProxyEnabled()) {
            if (!sHicnServiceGot) {
                if (hicnMgr == null) {
                    // hicnMgr not instantiated - yet
                    HicnManager localHicnMgr = HicnManager.getInstance(null);
                    if (localHicnMgr != null) {
                        sHicnServiceGot = true;
                    }
                } else {
                    sHicnServiceGot = true;
                }
            }
        }

        return sHicnServiceGot;
    }
*/

    protected ProxyBackend(final Service parentService) {
        HProxyLibrary.getInstance().setService(parentService);

        mParentService = parentService;
        mHandler = new Handler(this);

        updateForegroundNotification(R.string.hproxy_connecting);
        mHandler.sendEmptyMessage(R.string.hproxy_connecting);
    }

    @Override
    public boolean handleMessage(Message message) {
        Toast.makeText(mParentService, message.what, Toast.LENGTH_SHORT).show();
        if (message.what != R.string.hproxy_disconnected) {
            updateForegroundNotification(message.what);
        }

        return true;
    }

    public void disconnect() {
        mHandler.sendEmptyMessage(R.string.hproxy_disconnect);
        stop();

        setConnectingThread(null);
    }

    public boolean connect() {
//        try {
//            mParentService.getPackageManager().getPackageInfo(HProxy.getProxifiedPackageName(), 0);
//        } catch (PackageManager.NameNotFoundException e) {
//            String stringMessage = HProxy.getProxifiedAppName() + " " + mParentService.getString(R.string.not_found);
//            Toast.makeText(mParentService, stringMessage, Toast.LENGTH_LONG).show();
//            updateForegroundNotification(stringMessage);
//
//            disconnect();
//            return false;
//        }

        doConnect();
        return true;
    }

    /**
     * Optionally, set an intent to configure the VPN. This is {@code null} by default.
     */
    public void setConfigureIntent(PendingIntent intent) {
        mConfigureIntent = intent;
    }

    @Override
    public void run() {
        HProxyLibrary.getInstance().setProxyInstance(this);
        HProxyLibrary.getInstance().start(); //mServerName, mServerPort);

        Log.i(getTag(), "HProxy stopped.");

        //HProxy.getInstance().destroy();

        /*
        try {
            Log.i(getTag(), "Starting");
            final SocketAddress serverAddress = new InetSocketAddress(mServerName, mServerPort);
            for (int attempt = 0; attempt < MAX_HANDSHAKE_ATTEMPTS; ++attempt) {
                // Reset the counter if we were connected.
                if (run(serverAddress)) {
                    attempt = 0;
                }
                // Sleep for a while. This also checks if we got interrupted.
                Thread.sleep(RECONNECT_WAIT_MS);
            }
            Log.i(getTag(), "Giving up");
        } catch (IOException | InterruptedException | IllegalArgumentException e) {
            Log.e(getTag(), "Proxy stopped, exiting", e);
        }
         */
    }

    private void doConnect() {
        // Get an instance of the proxy
        // Replace any existing connecting thread with the  new one.
        final Thread thread = new Thread(this, "HProxyBackendThread");
        setConnectingThread(thread);

        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(mParentService);
//        mServerName = prefs.getString(mParentService.getString(R.string.hproxy_server_key), mParentService.getString(R.string.default_hproxy_server));
//        final String serverPortString = prefs.getString(mParentService.getString(R.string.hproxy_server_port_key), mParentService.getString(R.string.default_hproxy_server_port));
//        mServerPort = Integer.parseInt(serverPortString);
        mSharedSecret = prefs.getString(mParentService.getString(R.string.hproxy_secret_key), mParentService.getString(R.string.default_hproxy_secret));
        //mProxiedPackages = new String[]{HProxy.getProxifiedPackageName()};

        thread.start();
    }

    private void setConnectingThread(final Thread thread) {
        final Thread oldThread = mConnectingThread.getAndSet(thread);
        if (oldThread != null) {
            oldThread.interrupt();
        }
    }

    private void updateForegroundNotification(final int message) {
        final String NOTIFICATION_CHANNEL_ID = "12345";
        NotificationManager mNotificationManager = (NotificationManager) mParentService.getSystemService(
                mParentService.NOTIFICATION_SERVICE);
        mNotificationManager.createNotificationChannel(new NotificationChannel(
                NOTIFICATION_CHANNEL_ID, NOTIFICATION_CHANNEL_ID,
                NotificationManager.IMPORTANCE_LOW));
        mParentService.startForeground(Constants.FOREGROUND_SERVICE, new Notification.Builder(mParentService, NOTIFICATION_CHANNEL_ID)
                .setContentText(mParentService.getString(message))
//                .setContentIntent(mConfigureIntent)
                .build());
    }

    private void updateForegroundNotification(final String message) {
        final String NOTIFICATION_CHANNEL_ID = "12345";
        NotificationManager mNotificationManager = (NotificationManager) mParentService.getSystemService(
                mParentService.NOTIFICATION_SERVICE);
        mNotificationManager.createNotificationChannel(new NotificationChannel(
                NOTIFICATION_CHANNEL_ID, NOTIFICATION_CHANNEL_ID,
                NotificationManager.IMPORTANCE_DEFAULT));
        mParentService.startForeground(Constants.FOREGROUND_SERVICE, new Notification.Builder(mParentService, NOTIFICATION_CHANNEL_ID)
                .setContentText(message)
//                .setContentIntent(mConfigureIntent)
                .build());
    }

    /*
    private boolean run(SocketAddress server)
            throws IOException, InterruptedException, IllegalArgumentException {

        //
        //Forwarder forwarder = Forwarder.getInstance();
        //
        //while (!forwarder.isRunningForwarder()) {
        //    // wait for the forwarder ro run.
        //    Log.d(getTag(), "Hicn forwarder is not started yet. Waiting before activating the proxy.");
        //    TimeUnit.MILLISECONDS.sleep(500);
        //}
        //

        HProxy.getInstance().setProxyInstance(this);
        HProxy.getInstance().start(mServerName, mServerPort);

        Log.i(getTag(), "HProxy stopped.");

        //HProxy.getInstance().destroy();

        return true;
    }
*/

    public void stop() {
        HProxyLibrary.stopInstance();
    }

    public int configureTun(Properties parameters) {
        // If the old interface has exactly the same parameters, use it!
        if (mInterface != null && parameters.equals(mParameters)) {
            Log.i(getTag(), "Using the previous interface");
            return -1;
        }

        VpnService.Builder builder = ((VpnService)mParentService).new Builder();
        try {
            String param1 = null;
            String param2 = null;

            builder.setMtu(MAX_PACKET_SIZE);

            param1 = parameters.getProperty("ADDRESS");
            param2 = parameters.getProperty("PREFIX_LENGTH");
            builder.addAddress(param1, Integer.parseInt(param2));

            param1 = parameters.getProperty("ROUTE_ADDRESS");
            param2 = parameters.getProperty("ROUTE_PREFIX_LENGTH");
            builder.addRoute(param1, Integer.parseInt(param2));

            param1 = parameters.getProperty("DNS");
            builder.addDnsServer(param1);

        } catch (Exception e) {
            throw new IllegalArgumentException("Bad parameter");
        }


        //for (String s : mProxiedPackages) {
        for (PuntingSpec p : HProxyLibrary.getPuntingSpecs()) {
            try {
                SharedPreferences settings = mParentService.getSharedPreferences(PuntingSpec.PREFS_NAME, 0);
                boolean punt = settings.getBoolean(p.androidPackage, p.puntByDefault);
                if (!punt)
                    continue;
                    builder.addAllowedApplication(p.androidPackage);
            } catch (PackageManager.NameNotFoundException e) {
                //Log.e(getTag(), HProxy.getProxifiedAppName() + " is not installed.");
                Log.e(getTag(), p.appName + " is not installed.");
            }
        }

        // Close the old interface since the parameters have been changed.
        try {
            mInterface.close();
        } catch (Exception e) {
            // ignore
        }

        // Create a new interface using the builder and save the parameters.
        mInterface = builder.setSession("HProxy VPN session. Connected to server: "
                + mServerName
                + ":"
                + mServerPort)
                .setConfigureIntent(mConfigureIntent)
                .establish();
        mParameters = parameters;

        synchronized (mParentService) {
            mInterface = builder.establish();
            mHandler.sendEmptyMessage(R.string.hproxy_connected);
        }

        mTunFd = mInterface.getFd();;

        Log.i(getTag(), "New interface: " + mInterface + " (" + parameters + ")");

        return mTunFd;
    }

    public int closeTun() {
        try {
            mInterface.close();
        } catch(IOException e) {
            Log.e(getTag(), "Closing VPN interface", e);
        }

        return 0;
    }

    private final String getTag() {
        return "HProxyBackend"; //ProxyBackend.class.getSimpleName();
    }
}
