package com.cisco.hicn.forwarder.applications;

import android.graphics.drawable.Drawable;

public class Application {
    public Application(String name, String packageName, Drawable icon)
    {
        name_ = name;
        packageName_ = packageName;
        icon_ = icon;
    }

    String getName()
    {
        return name_;
    }

    String getPackageName()
    {
        return packageName_;
    }

    Drawable getIcon()
    {
        return icon_;
    }

    boolean getPuntByDefault() { return puntByDefault_; }
    void setPuntByDefault(boolean value) { puntByDefault_ = value; }

    private String name_;
    private String packageName_;
    private Drawable icon_;
    private boolean puntByDefault_;
}
